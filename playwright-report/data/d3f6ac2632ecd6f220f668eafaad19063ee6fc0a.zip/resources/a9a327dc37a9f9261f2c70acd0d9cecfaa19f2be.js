function doubleClickAction() {
  var result = document.getElementById("double-click-result");
    result.style.display = "block";
    result.innerHTML = "Congrats, you double clicked!";
}
